import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Mwangi",
    role: "CEO, FinFlow Africa",
    quote: "PachoLabs transformed our vision into a seamless mobile banking app. Their M-Pesa integration expertise saved us months of development time.",
    rating: 5,
  },
  {
    name: "James Ochieng",
    role: "CTO, GreenHarvest",
    quote: "The AI crop detection platform they built has been a game-changer for our farming operations. Accurate, fast, and incredibly reliable.",
    rating: 5,
  },
  {
    name: "Amina Hassan",
    role: "Director, SecureLegal Ltd",
    quote: "Their cybersecurity audit uncovered critical vulnerabilities we didn't know existed. Professional, thorough, and genuinely invested in our safety.",
    rating: 5,
  },
  {
    name: "David Kimani",
    role: "Founder, LogiPrime",
    quote: "Our warehouse efficiency improved by 80% after PachoLabs automated our workflows. Best technology investment we've ever made.",
    rating: 5,
  },
];

const TestimonialsSection = () => {
  return (
    <section id="testimonials" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-primary font-medium mb-3 tracking-wide uppercase text-sm">Testimonials</p>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">What Our Clients Say</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Don't just take our word for it — hear from the businesses we've helped grow.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="glass rounded-xl p-8 flex flex-col hover:bg-surface-hover transition-all duration-300"
            >
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                ))}
              </div>
              <blockquote className="text-secondary-foreground leading-relaxed mb-6 flex-1">
                "{t.quote}"
              </blockquote>
              <div>
                <p className="font-display font-semibold">{t.name}</p>
                <p className="text-sm text-muted-foreground">{t.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
