import { CheckCircle2 } from "lucide-react";

const highlights = [
  "Agile development with rapid delivery",
  "Scalable architecture from day one",
  "24/7 support and maintenance",
  "Industry-leading security practices",
  "Cross-platform expertise",
  "Data-driven decision making",
];

const AboutSection = () => {
  return (
    <section id="about" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <p className="text-primary font-medium mb-3 tracking-wide uppercase text-sm">Why Choose Us</p>
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-6">
              Technology Partner You Can{" "}
              <span className="text-gradient">Trust</span>
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-8">
              We're a team of engineers, designers, and strategists passionate about building technology that makes a difference. From startups to enterprises, we deliver solutions that are robust, secure, and built to grow with your business.
            </p>
            <div className="grid sm:grid-cols-2 gap-3">
              {highlights.map((item) => (
                <div key={item} className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                  <span className="text-sm text-secondary-foreground">{item}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="glass rounded-2xl p-8 space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground text-sm">Projects Delivered</span>
                <span className="font-display text-3xl font-bold text-gradient">150+</span>
              </div>
              <div className="h-px bg-border" />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground text-sm">Happy Clients</span>
                <span className="font-display text-3xl font-bold text-gradient">80+</span>
              </div>
              <div className="h-px bg-border" />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground text-sm">Years of Experience</span>
                <span className="font-display text-3xl font-bold text-gradient">8+</span>
              </div>
              <div className="h-px bg-border" />
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground text-sm">Team Members</span>
                <span className="font-display text-3xl font-bold text-gradient">25+</span>
              </div>
            </div>
            {/* Decorative glow */}
            <div className="absolute -inset-4 bg-primary/5 rounded-3xl blur-2xl -z-10" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
