const Footer = () => {
  return (
    <footer className="border-t border-border py-10 px-6">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <span className="font-display font-bold text-gradient">PachoLabs</span>
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} PachoLabs. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
