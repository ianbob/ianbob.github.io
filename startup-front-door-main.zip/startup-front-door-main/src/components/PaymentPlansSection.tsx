import { HandCoins } from "lucide-react";
import { Button } from "@/components/ui/button";

const PaymentPlansSection = () => {
  return (
    <section id="pricing" className="py-24 px-6">
      <div className="max-w-6xl mx-auto text-center mb-16">
        <p className="text-primary font-medium mb-3 tracking-wide uppercase text-sm">Flexible Pricing</p>
        <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Choose Your Plan</h2>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Whether you're a startup or an enterprise, we have a plan that fits your needs and budget.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
        {/* Basic Plan */}
        <div className="glass rounded-xl p-8 flex flex-col items-center">
          <HandCoins className="w-10 h-10 text-primary mb-4" />
          <h3 className="font-display text-2xl font-semibold mb-2">Basic</h3>
          <p className="text-muted-foreground text-sm mb-6">Perfect for startups and small businesses.</p>
          <div className="text-3xl font-bold mb-4">$499/mo</div>
          <ul className="text-left space-y-2 mb-6">
            <li>✓ 5 Projects</li>
            <li>✓ Basic Support</li>
            <li>✓ Access to Community Resources</li>
          </ul>
            <Button asChild variant="hero" size="lg" className="w-full text-base py-6">
                <a href="http://paystack.shop/pay/r-32iu-mlu" target="_blank" rel="noopener noreferrer">
                    Get Started
                </a>
            </Button>
        </div>

        {/* Pro Plan */}
        <div className="glass rounded-xl p-8 flex flex-col items-center border-2 border-primary">
          <HandCoins className="w-10 h-10 text-primary mb-4" />
          <h3 className="font-display text-2xl font-semibold mb-2">Pro</h3>
          <p className="text-muted-foreground text-sm mb-6">Ideal for growing businesses and teams.</p>
          <div className="text-3xl font-bold mb-4">$999/mo</div>
          <ul className="text-left space-y-2 mb-6">
            <li>✓ 20 Projects</li>
            <li>✓ Priority Support</li>
            <li>✓ Access to Beta Features</li>
          </ul>
            <Button asChild variant="hero" size="lg" className="w-full text-base py-6">
                <a href="http://paystack.shop/pay/r-32iu-mlu" target="_blank" rel="noopener noreferrer">
                    Get Started
                </a>
            </Button>
        </div>

        {/* Enterprise Plan */}
        <div className="glass rounded-xl p-8 flex flex-col items-center">
          <HandCoins className="w-10 h-10 text-primary mb-4" />
          <h3 className="font-display text-2xl font-semibold mb-2">Enterprise</h3>
          <p className="text-muted-foreground text-sm mb-6">Custom solutions for large organizations.</p>
          <div className="text-3xl font-bold mb-4">Contact Us</div>
          <ul className="text-left space-y-2 mb-6">
            <li>✓ Unlimited Projects</li>
            <li>✓ Dedicated Support Team</li>
            <li>✓ Custom Integrations</li>
          </ul>
            <Button asChild variant="hero" size="lg" className="w-full text-base py-6">
                <a href="http://paystack.shop/pay/r-32iu-mlu" target="_blank" rel="noopener noreferrer">
                    Contact Sales
                </a>
            </Button>
        </div>
      </div>
    </section>
  );
};

export default PaymentPlansSection; 