import { Code2, Bot, BrainCircuit, Shield, Megaphone, Server, Wallet, Wifi } from "lucide-react";

const services = [
  {
    icon: Code2,
    title: "Web & Software Development",
    description: "Custom web applications, SaaS platforms, and enterprise software built with modern frameworks.",
  },
  {
    icon: Wifi,
    title: "Managed Wi‑Fi Hotspots",
    description: "End‑to‑end Wi‑Fi hotspot management with user authentication, bandwidth control, and monetization options.",
  },
  {
    icon: Bot,
    title: "Business Automation",
    description: "Streamline workflows, automate repetitive tasks, and boost your team's productivity.",
  },
  {
    icon: BrainCircuit,
    title: "AI & Data Solutions",
    description: "Machine learning models, data analytics, and intelligent systems that drive decisions.",
  },
  {
    icon: Server,
    title: "IT Support & Infrastructure",
    description: "Reliable IT support, cloud infrastructure, and managed services to keep you running.",
  },
  {
    icon: Shield,
    title: "Cybersecurity",
    description: "Protect your business with security audits, penetration testing, and compliance solutions.",
  },
  {
    icon: Megaphone,
    title: "Digital Marketing & SEO",
    description: "Data-driven marketing strategies, SEO optimization, and content that converts.",
  },
  {
    icon: Wallet,
    title: "M-Pesa Integration",
    description: "Seamless M-Pesa payment integration for your apps and platforms across East Africa.",
  },
];

const ServicesSection = () => {
  return (
    <section id="services" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-primary font-medium mb-3 tracking-wide uppercase text-sm">What We Do</p>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Our Services</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            End-to-end technology solutions tailored to accelerate your business growth.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {services.map((service) => (
            <div
              key={service.title}
              className="group glass rounded-xl p-6 hover:bg-surface-hover transition-all duration-300 hover:glow-border"
            >
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <service.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-display font-semibold text-lg mb-2">{service.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
