import { ArrowUpRight } from "lucide-react";

const projects = [
  {
    title: "FinFlow Mobile App",
    category: "Mobile App · Fintech",
    description: "A cross-platform mobile banking app with M-Pesa integration serving 50K+ users across East Africa.",
    tags: ["React Native", "M-Pesa", "Node.js"],
  },
  {
    title: "SmartCrop AI Platform",
    category: "AI · Agriculture",
    description: "Machine learning-powered crop disease detection and yield prediction for commercial farms.",
    tags: ["Python", "TensorFlow", "IoT"],
  },
  {
    title: "SecureVault Enterprise",
    category: "Cybersecurity · SaaS",
    description: "End-to-end encrypted document management system for legal and financial institutions.",
    tags: ["React", "AWS", "Zero-Trust"],
  },
  {
    title: "LogiTrack Automation",
    category: "Automation · Logistics",
    description: "Warehouse automation platform that reduced manual processing by 80% for a major distributor.",
    tags: ["Next.js", "RPA", "PostgreSQL"],
  },
  {
    title: "HealthConnect Portal",
    category: "Web App · Healthcare",
    description: "Telemedicine platform connecting patients with specialists, featuring real-time video consultations.",
    tags: ["WebRTC", "React", "HIPAA"],
  },
  {
    title: "GrowthPulse SEO Suite",
    category: "Digital Marketing · SaaS",
    description: "SEO analytics dashboard that helped clients achieve 3x organic traffic growth in 6 months.",
    tags: ["Analytics", "SEO", "React"],
  },
];

const ProjectsSection = () => {
  return (
    <section id="projects" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-primary font-medium mb-3 tracking-wide uppercase text-sm">Our Work</p>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Featured Projects</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            A selection of projects we've delivered for clients across industries.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {projects.map((project) => (
            <div
              key={project.title}
              className="group glass rounded-xl overflow-hidden hover:bg-surface-hover transition-all duration-300 hover:glow-border"
            >
              <div className="h-40 bg-gradient-to-br from-primary/10 to-[hsl(270,80%,65%)]/10 flex items-center justify-center">
                <span className="font-display text-2xl font-bold text-primary/30 group-hover:text-primary/50 transition-colors">
                  {project.title.split(" ")[0]}
                </span>
              </div>
              <div className="p-6">
                <p className="text-xs text-primary font-medium tracking-wide uppercase mb-2">{project.category}</p>
                <h3 className="font-display font-semibold text-lg mb-2 flex items-center gap-2">
                  {project.title}
                  <ArrowUpRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span key={tag} className="text-xs px-2.5 py-1 rounded-full bg-muted text-muted-foreground">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
