import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mail, MapPin, Phone } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const ContactSection = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Message sent!", description: "We'll get back to you soon." });
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <section id="contact" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-primary font-medium mb-3 tracking-wide uppercase text-sm">Get In Touch</p>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Let's Build Together</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Ready to transform your business? Reach out and let's discuss your project.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          <form onSubmit={handleSubmit} className="glass rounded-2xl p-8 space-y-6">
            <Input
              placeholder="Your Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="bg-muted/50 border-border/50 h-12"
              required
            />
            <Input
              type="email"
              placeholder="Your Email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="bg-muted/50 border-border/50 h-12"
              required
            />
            <Textarea
              placeholder="Tell us about your project..."
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              className="bg-muted/50 border-border/50 min-h-[140px]"
              required
            />
            <Button variant="hero" size="lg" className="w-full text-base py-6">
              Send Message
            </Button>
          </form>

          <div className="flex flex-col justify-center space-y-8">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Mail className="w-5 h-5 text-primary" />
              </div>              
              <div>
                <h4 className="font-display font-semibold mb-1">Email Us</h4>
                <a href="mailto:info@pacholabs.com" className="text-muted-foreground hover:text-primary block">
                  info@pacholabs.com
                </a>
                <a href="mailto:support@pacholabs.com" className="text-muted-foreground hover:text-primary block">
                  support@pacholabs.com
                </a>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Phone className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h4 className="font-display font-semibold mb-1">Call Us</h4>
                <a href="tel:+254788716028" className="text-muted-foreground hover:text-primary block">
                  +254 788 716 028
                </a>
                <a href="tel:+254795093768" className="text-muted-foreground hover:text-primary block">
                  +254 795 093 768
                </a>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <MapPin className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h4 className="font-display font-semibold mb-1">Visit Us</h4>
                <p className="text-muted-foreground">Lower Kabete, Nairobi, Kenya</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
