import { ArrowRight, Clock } from "lucide-react";

const posts = [
  {
    title: "Why Every Business Needs a Cybersecurity Audit in 2026",
    excerpt: "Cyber threats are evolving fast. Here's how a proactive security audit can save your business from costly breaches.",
    category: "Cybersecurity",
    readTime: "5 min read",
    date: "Mar 28, 2026",
  },
  {
    title: "M-Pesa Integration: A Developer's Complete Guide",
    excerpt: "Step-by-step walkthrough for integrating M-Pesa payments into your web and mobile applications.",
    category: "Development",
    readTime: "8 min read",
    date: "Mar 15, 2026",
  },
  {
    title: "How AI Is Transforming Small Business Operations",
    excerpt: "From chatbots to predictive analytics — practical AI use cases that deliver real ROI for SMEs.",
    category: "AI & Automation",
    readTime: "6 min read",
    date: "Mar 5, 2026",
  },
];

const BlogSection = () => {
  return (
    <section id="blog" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-primary font-medium mb-3 tracking-wide uppercase text-sm">Insights</p>
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">From Our Blog</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Thoughts, guides, and industry insights from the PachoLabs team.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {posts.map((post) => (
            <article
              key={post.title}
              className="group glass rounded-xl p-6 flex flex-col hover:bg-surface-hover transition-all duration-300 hover:glow-border cursor-pointer"
            >
              <span className="text-xs text-primary font-medium tracking-wide uppercase mb-3">{post.category}</span>
              <h3 className="font-display font-semibold text-lg mb-3 leading-snug group-hover:text-primary transition-colors">
                {post.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed mb-6 flex-1">{post.excerpt}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{post.readTime}</span>
                  <span>·</span>
                  <span>{post.date}</span>
                </div>
                <ArrowRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BlogSection;
